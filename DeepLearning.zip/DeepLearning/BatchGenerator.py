import numpy as np
import math

def batch_generator(dataset, group, batch_size):

    #training_prop = 0.6
    training_quant = 15000
    idx = 0

    #print("Test")


    if group == 'train':
        data_batch = dataset[0:training_quant]

        #data_batch = dataset[0:int(np.round(training_prop * len(dataset), 0))]
    else:
        data_batch = dataset[training_quant + 1:]
        #data_batch = dataset[int(np.round(training_prop * len(dataset), 0) + 1)]
    #print()
    dataset_size = len(data_batch)
    indices = list(range(dataset_size))
    np.random.shuffle(indices)
    while idx < dataset_size:
        chunk = slice(idx, idx + batch_size)
        chunk = indices[chunk]
        chunk = sorted(chunk)
        idx = idx + batch_size
        yield [data_batch[i] for i in chunk]
