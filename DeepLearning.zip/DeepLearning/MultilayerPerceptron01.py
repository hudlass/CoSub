# ==============================================================================
# ==============================================================================
# Multilayer Perceptron - Version 001 ==========================================
# Luke Hudlass-Galley ==========================================================
# ==============================================================================
# ==============================================================================

# Imports and packages =========================================================
from BatchGenerator import *

import tensorflow as tf
import numpy      as np
import math
import csv

# Sort out and formulate data ==================================================
data = list(csv.reader(open('../Data/8Puzzle.csv')))
print("Data imported")

# Network parameters ===========================================================
learning_rate = 0.05

# Network properties ===========================================================
n_hidden_1 = 100
n_hidden_2 = 300
n_hidden_3 = 200
n_hidden_4 = 150

n_input    = 8
n_classes  = 1

# Network architecture =========================================================
def multilayer_perceptron(x, weights, biases):
    # Layer 1 ==================================================================
    layer_1 = tf.add(tf.matmul(x, weights['h1']), biases['b1'])
    layer_1 = tf.nn.relu(layer_1)

    # Layer 2 ==================================================================
    layer_2 = tf.add(tf.matmul(layer_1, weights['h2']), biases['b2'])
    layer_2 = tf.nn.relu(layer_2)

    # Layer 3 ==================================================================
    layer_3 = tf.add(tf.matmul(layer_2, weights['h3']), biases['b3'])
    layer_3 = tf.nn.relu(layer_3)

    # Layer 4 ==================================================================
    layer_4 = tf.add(tf.matmul(layer_3, weights['h4']), biases['b4'])
    layer_4 = tf.nn.relu(layer_4)

    # Output layer =============================================================
    out_layer = tf.matmul(layer_4, weights['out']) + biases['out']
    return out_layer

# Weights and biases ===========================================================
weights = {
            'h1':  tf.Variable(tf.random_normal([n_input,    n_hidden_1], stddev=0.1)),
            'h2':  tf.Variable(tf.random_normal([n_hidden_1, n_hidden_2], stddev=0.1)),
            'h3':  tf.Variable(tf.random_normal([n_hidden_2, n_hidden_3], stddev=0.1)),
            'h4':  tf.Variable(tf.random_normal([n_hidden_3, n_hidden_4], stddev=0.1)),
            'out': tf.Variable(tf.random_normal([n_hidden_4, n_classes],  stddev=0.1))
          }
biases  = {
            'b1':  tf.Variable(tf.random_normal([n_hidden_1], stddev=0.1)),
            'b2':  tf.Variable(tf.random_normal([n_hidden_2], stddev=0.1)),
            'b3':  tf.Variable(tf.random_normal([n_hidden_3], stddev=0.1)),
            'b4':  tf.Variable(tf.random_normal([n_hidden_4], stddev=0.1)),
            'out': tf.Variable(tf.random_normal([n_classes],  stddev=0.1))
          }

# Construct model
def main():

    monitoring_freq = 100
    max_steps = 10000
    learning_rate = 0.0001

    x = tf.placeholder("float", [None, n_input])
    y = tf.placeholder("float", [None, n_classes])

    batch_size = 64

    train_batch_gen = batch_generator(data, 'train', batch_size)
    val_batch_gen   = batch_generator(data, 'test',  batch_size)
    test_batch_gen  = batch_generator(data, 'test',  batch_size)

    pred = multilayer_perceptron(x, weights, biases)
    cost = tf.losses.mean_squared_error(y, pred)

    train_step = tf.train.AdamOptimizer(learning_rate).minimize(cost)

    correct  = tf.equal(tf.round(y), tf.round(pred))
    accuracy = tf.reduce_mean(tf.cast(correct, 'float'))

    init_op = tf.group(tf.global_variables_initializer(),
              tf.local_variables_initializer())


    with tf.Session() as sess:
        sess.run(init_op)

        print('=============== Training ===============')
        for step in range(max_steps):

            # Getting train batch
            train_batch = next(train_batch_gen)
            if len(train_batch[0]) != batch_size:
                train_batch_gen = batch_generator(data, 'train', batch_size)
                train_batch = next(train_batch_gen)

            train_batch = np.asarray(train_batch)
            train_input = train_batch[:, 1:-1]
            train_label = train_batch[:, 0]


            train_label = train_label.reshape(batch_size, n_classes)

            _ = sess.run(train_step, feed_dict={x: train_input, y: train_label})

            if step % (monitoring_freq) == 0:
                val_batch = next(val_batch_gen)

                if len(val_batch[0]) != batch_size:
                    val_batch_gen = batch_generator(data, 'test', batch_size)
                    val_batch = next(val_batch_gen)

                val_batch = np.asarray(val_batch)
                val_input = val_batch[:, 1:-1]
                val_label = val_batch[:, 0]

                val_label = val_label.reshape(batch_size, n_classes)

                val_accuracy, val_loss = sess.run([accuracy, cost], feed_dict={x: val_input, y: val_label})
                train_loss = sess.run(cost, feed_dict={x: train_input, y: train_label})

                print('Step : {} - Training Loss : {} - Validation Accuracy : {} - Validation Loss : {}'.format(step, train_loss, val_accuracy, val_loss))


main()
